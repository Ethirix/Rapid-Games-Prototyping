using System;
using UnityEngine;

[RequireComponent(typeof(CheckpointManager), typeof(PlayerRespawnManager))]
public class GameManager : MonoBehaviour
{
    public CheckpointManager CheckpointManager;
    public PlayerRespawnManager PlayerRespawnManager;
    public GameState GameState { get; private set; } = GameState.None;

    private void Start()
    {
        GameState = GameState.Loading;
        CheckpointManager = GetComponent<CheckpointManager>();
        PlayerRespawnManager = GetComponent<PlayerRespawnManager>();
        CheckpointManager.OnWin += OnWin;

        GameState = GameState.Playing;
    }

    private void OnDisable()
    {
        CheckpointManager.OnWin -= OnWin;
    }

    private void OnWin(object sender, EventArgs e)
    {
        Debug.Log("Game Won");
        GameState = GameState.Won;
        Time.timeScale = 0;
    }
}

public enum GameState
{
    None,
    Loading,
    Playing,
    Won
}
